## 6.6 URDF集成Gazebo

URDF 需要集成进 Rviz 或 Gazebo 才能显示可视化的机器人模型，前面已经介绍了URDF 与 Rviz 的集成，本节主要介绍:

* URDF 与 Gazebo 的基本集成流程；
* 如果要在 Gazebo 中显示机器人模型，URDF 需要做的一些额外配置；
* 关于Gazebo仿真环境的搭建。



