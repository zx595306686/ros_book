### 4.2.1 launch文件标签之launch

`<launch>`标签是所有 launch 文件的根标签，充当其他标签的容器

#### 1.属性

* `deprecated = "弃用声明"`

  告知用户当前 launch 文件已经弃用

#### 2.子级标签

所有其它标签都是 roslacun 的子级

