## 1.3 ROS初体验

编写 ROS 程序，在控制台输出文本: Hello World，分别使用 C++ 和 Python 实现。

