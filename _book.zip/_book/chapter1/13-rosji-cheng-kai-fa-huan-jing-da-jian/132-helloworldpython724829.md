### 1.3.2 HelloWorld\(Python版\)

ROS 的 python 实现与 C++ 实现步骤类似，步骤1和步骤2完全一致，也可以上接前面案例，在之前的工作空间的功能包中添加 python 实现

#### 1.进入 ros 包添加 scripts 目录并编辑 python 文件

```
cd ros包
mkdir scripts
```

新建 python 文件: \(文件名自定义\)

```py
#! /usr/bin/env python

"""
	Python 版 HelloWorld

"""
import rospy

if __name__ == "__main__":
	rospy.init_node("Hello")
	rospy.loginfo("Hello World!!!!")
```

#### 2.为 python 文件添加可执行权限

```
chmod +x 自定义文件名.py
```

#### 3.编辑 ros 包下的 CamkeList.txt 文件

```
catkin_install_python(PROGRAMS scripts/自定义文件名.py
  DESTINATION ${CATKIN_PACKAGE_BIN_DESTINATION}
)
```

#### 4.进入工作空间目录并执行\(无需编译\)

先保证 roscore 启动

```
cd 工作空间
source ./devel/setup.bash
rosrun 包名 自定义文件名.py
```

输出结果:`Hello World!!!!`

