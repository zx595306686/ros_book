### 1.2.1 安装虚拟机软件

#### 1.下载virtualbox

安装 virtualbox 需要先访问官网，下载安装包，官网下载地址:[https://www.virtualbox.org/wiki/Downloads](https://www.virtualbox.org/wiki/Downloads)![](/assets/14_virtualbox下载.png "14\_virtualbox下载")

#### 2.安装virtualbox

virtualbox 安装比较简单，如果没有特殊需求，双击安装文件，一直 "下一步" 即可。

![](/assets/15_VB安装1.png "15\_VB安装1")

![](/assets/16_VB安装2.png "16\_VB安装1")

![](/assets/17_VB安装3.png "17\_VB安装3")

![](/assets/18_VB安装4.png "18\_VB安装4")

![](/assets/19_VB安装5.png "19\_VB安装5")

![](/assets/20_VB安装6.png "20\_VB安装6")

![](/assets/21_VB安装7.png "21\_VB安装7")

![](/assets/22_VB安装8.png "22\_VB安装8")

![](/assets/23_VB安装9.png "23\_VB安装9")

安装完毕后，虚拟机已经可以正常启动了，接下来需要使用其虚拟出一台计算机

