#### 5.2.4 rosbag实操A\(Python\)



