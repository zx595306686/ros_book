## 5.3.2 rqt常用插件:rqt\_graph

**简介:**可视化显示计算图

**启动:**可以在 rqt 的 plugins 中添加，或者使用`rqt_graph`启动

![](/assets/02_rqt_graph插件.png)

