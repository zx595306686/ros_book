### 5.3.1 rqt安装启动与及基本使用

#### 1.安装

* 一般只要你安装的是desktop-full版本就会自带工具箱

* 如果需要安装可以以如下方式安装

  ```
  $ sudo apt-get install ros-noetic-rqt
  $ sudo apt-get install ros-noetic-rqt-common-plugins
  ```

#### 2.启动

`rqt`的启动方式有两种:

* 方式1:`rqt`

* 方式2:`rosrun rqt_gui rqt_gui`

#### 3.基本使用

启动 rqt 之后，可以通过 plugins 添加所需的插件![](/assets/13rqt工具箱.PNG)

