### 5.3.5 rqt常用插件:rqt\_bag

**简介:**录制和重放 bag 文件的图形化插件

**准备:**启动 turtlesim 乌龟节点与键盘控制节点

**启动:**可以在 rqt 的 plugins 中添加，或者使用`rqt_bag`启动

**录制:**![](/assets/14rqt_bag_录制.png)

**重放:**![](/assets/15rqt_bag_回放.png)

